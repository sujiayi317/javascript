# Note Manager Using DOM
